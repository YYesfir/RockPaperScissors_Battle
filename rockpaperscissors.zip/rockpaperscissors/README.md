<h1>Rock Paper Scissors Game</h1><br/>
This program replicates the Rock Paper Scissors Game. <br/><br/>
You can use in Intellis IDEA.<br/>
Open the MovingObjects. java and run it.
