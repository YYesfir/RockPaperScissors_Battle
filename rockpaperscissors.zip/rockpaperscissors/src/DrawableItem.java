import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class DrawableItem {

	private Image image;
	private double x;
	private double y;
	private double xSpeed;
	private double ySpeed;
	private int imageWidth;
	private int imageHeight;
	private Random random;
	public int item; // 3 - rock, 2 - scissors, 1 - paper

	public DrawableItem(int item, String imagePath, double x, double y, double xSpeed, double ySpeed, int imageWidth, int imageHeight) {
		this.x = x;
		this.y = y;
		this.xSpeed = xSpeed;
		this.ySpeed = ySpeed;
		this.imageWidth = imageWidth;
		this.imageHeight = imageHeight;
		this.random = new Random();
		this.setImage(imagePath);
		this.item = item;
	}

	public void setImage(String imagePath) {
		this.image = new ImageIcon(imagePath).getImage();
	}

	public void update(int panelWidth, int panelHeight) {
		x += xSpeed;
		y += ySpeed;
		if (x < 0 || x + imageWidth > panelWidth) {
			xSpeed = -xSpeed;
		}
		if (y < 0 || y + imageHeight > panelHeight) {
			ySpeed = -ySpeed;
		}
	}

	public void draw(Graphics g) {
		g.drawImage(image, (int) x, (int) y, imageWidth, imageHeight, null);
	}

	public void reverseDirection() {
		xSpeed = -xSpeed;
		ySpeed = -ySpeed;
	}

	public boolean intersects(DrawableItem other) {
		return (
			this.x + this.image.getWidth(null) >= other.x &&
			this.y + this.image.getHeight(null) >= other.y &&
			other.x + other.image.getWidth(null) >= this.x &&
			other.y + other.image.getHeight(null) >= this.y
		);
	}
}
