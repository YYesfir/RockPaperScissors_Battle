import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.*;

public class MovingObjects extends JFrame implements ActionListener {
	private DrawingPanel drawingPanel;
	private ArrayList<DrawableItem> items;
	private Timer timer;
	private Random rand;
	private Clip clip;

	public static void main(String[] args) {
		new MovingObjects().setVisible(true);
	}

	public MovingObjects() {
		super("Moving Objects");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);

		drawingPanel = new DrawingPanel();
		add(drawingPanel, BorderLayout.CENTER);

		JPanel buttonPanel = new JPanel();
		JButton startButton = new JButton("Start");
		startButton.addActionListener(this);
		buttonPanel.add(startButton);
		JButton stopButton = new JButton("Stop");
		stopButton.addActionListener(this);
		buttonPanel.add(stopButton);
		add(buttonPanel, BorderLayout.SOUTH);

		pack();
		setLocationRelativeTo(null);

		rand = new Random();
		items = new ArrayList<DrawableItem>();
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("Start")) {
			start();
		} else if (e.getActionCommand().equals("Stop")) {
			stop();
		}
	}

	private void start() {
		if (timer != null && timer.isRunning()) {
			return;
		}
		int rocks = 5 + new Random().nextInt(10);
		int scissors = 5 + new Random().nextInt(10);
		int papers = 5 + new Random().nextInt(10);

		int width = drawingPanel.getWidth();
		int height = drawingPanel.getHeight();

		// create rocks
		for (int i = 0; i < rocks; i++) {
			DrawableItem item = new DrawableItem(3, "rock.png", rand.nextDouble() * (width - 50), rand.nextDouble() * (height - 50), rand.nextDouble(5) , rand.nextDouble(5), 50, 50);
			items.add(item);
		}

		// create scissors
		for (int i = 0; i < scissors; i++) {
			DrawableItem item = new DrawableItem(2, "scissors.png", rand.nextDouble() * (width - 50), rand.nextDouble() * (height - 50), rand.nextDouble(5), rand.nextDouble(5), 50, 50);
			items.add(item);
		}

		// create papers
		for (int i = 0; i < papers; i++) {
			DrawableItem item = new DrawableItem(1, "paper.png", rand.nextDouble() * (width - 50), rand.nextDouble() * (height - 50), rand.nextDouble(5), rand.nextDouble(5) , 50, 50);
			items.add(item);
		}

		// start timer
		timer = new Timer(30, new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				update();
			}
		});
		timer.start();

		try {
			AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(getClass().getResource("sounds/song.wav"));
			clip = AudioSystem.getClip();
			clip.open(audioInputStream);
			clip.loop(Clip.LOOP_CONTINUOUSLY);
		} catch (Exception ex) {
			System.out.println("Error playing background music: " + ex.getMessage());
		}
	}

	private void stop() {
		if (timer != null) {
			timer.stop();
			timer = null;
			items.clear();
			drawingPanel.repaint();
			clip.stop();
		}
	}

	private void update() {
		int width = drawingPanel.getWidth();
		int height = drawingPanel.getHeight();
		for (DrawableItem item : items) {
			item.update(width, height);
			drawingPanel.repaint();
		}
//		checkCollisions();
//		drawingPanel.repaint();
	}

	private void checkCollisions() {
		for (int i = 0; i < items.size(); i++) {
			DrawableItem item1 = items.get(i);
			for (int j = i + 1; j < items.size(); j++) {
				DrawableItem item2 = items.get(j);
				if (item1.intersects(item2) && item1.item != item2.item) {
					if (item1.item == 1 && item2.item == 2) {
						item1.setImage("scissors.png");
						item1.item = 2;
					} else if (item1.item == 1 && item2.item == 3) {
						item2.setImage("paper.png");
						item2.item = 1;
					} else if (item1.item == 2 && item2.item == 3) {
						item1.setImage("rock.png");
						item1.item = 3;
					}
					item1.reverseDirection();
					item2.reverseDirection();
				}
			}
		}
	}

	private class DrawingPanel extends JPanel {

		private BufferedImage backgroundImage;
		public DrawingPanel() {
			setPreferredSize(new Dimension(500, 500));
			try {
				backgroundImage = ImageIO.read(new File("background.png"));
			} catch (IOException e) {
				e.printStackTrace();
			}

		}


		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			g.drawImage(backgroundImage, 0, 0, null);
			for (DrawableItem item : items) {
				item.draw(g);
			}
		}
	}
}
